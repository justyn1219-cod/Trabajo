document.addEventListener("DOMContentLoaded", () => {
    const postsContainer = document.getElementById("postsContainer");
    const modal = document.getElementById("userModal");
    const closeBtn = document.querySelector(".close-btn");
    const modalBody = document.getElementById("modalBody");

    // URLs de la API de JSONPlaceholder
    const POSTS_URL = "https://jsonplaceholder.typicode.com/posts";
    const USERS_URL = "https://jsonplaceholder.typicode.com/users";

    // Cargar las cards de los posts
    async function loadPosts() {
        try {
            const response = await fetch(POSTS_URL);
            const posts = await response.json();
            
            // Mostrar los primeros 20 posts para una mejor interfaz
            postsContainer.innerHTML = posts.slice(0, 20).map(post => `
                <div class="card" data-user-id="${post.userId}">
                    <h3>${post.title}</h3>
                    <p>${post.body}</p>
                    <span class="user-badge">Ver Usuario #${post.userId}</span>
                </div>
            `).join("");

            // Asignar evento click a cada card generada
            document.querySelectorAll(".card").forEach(card => {
                card.addEventListener("click", () => {
                    const userId = card.getAttribute("data-user-id");
                    if (userId) {
                        showUserInfo(userId);
                    }
                });
            });
        } catch (error) {
            postsContainer.innerHTML = "<p>Error al cargar los posts.</p>";
            console.error("Error al obtener los posts:", error);
        }
    }

    // Cerrar el modal al hacer clic en la 'X'
    closeBtn.addEventListener("click", () => {
        modal.style.display = "none";
    });

    // Cerrar el modal al hacer clic fuera del contenido
    window.addEventListener("click", (event) => {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    // Obtener y mostrar la información del usuario por su ID
    async function showUserInfo(userId) {
        try {
            modalBody.innerHTML = "<p>Cargando información del usuario...</p>";
            modal.style.display = "block";

            const response = await fetch(`${USERS_URL}/${userId}`);
            const user = await response.json();

            // Muestra id, name, username, email, phone y website según el requerimiento
            modalBody.innerHTML = `
                <p><strong>ID:</strong> ${user.id}</p>
                <p><strong>Name:</strong> ${user.name}</p>
                <p><strong>Username:</strong> ${user.username}</p>
                <p><strong>Email:</strong> ${user.email}</p>
                <p><strong>Phone:</strong> ${user.phone}</p>
                <p><strong>Website:</strong> ${user.website}</p>
            `;
        } catch (error) {
            modalBody.innerHTML = "<p>Error al cargar la información del usuario.</p>";
            console.error("Error al obtener el usuario:", error);
        }
    }

    // Inicializar la carga de datos
    loadPosts();
});
